// Simple disparition après 5 secondes
setTimeout(() => {
  document.getElementById('preloader').style.opacity = '0';
  setTimeout(() => {
    document.getElementById('preloader').remove();
  }, 500); // Temps du fondu
}, 5000); // 5 secondes de chargement
// Dark Mode Toggle
const themeToggle = document.getElementById('theme-toggle');
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  document.body.classList.toggle('light-mode');
  
  const icon = document.body.classList.contains('dark-mode') 
    ? '<i class="fas fa-sun"></i>' 
    : '<i class="fas fa-moon"></i>';
  
  themeToggle.innerHTML = icon;
});

// Mobile Menu Toggle
const menuToggle = document.getElementById('menu-toggle');
const navLinks = document.getElementById('nav-links');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
  menuToggle.innerHTML = navLinks.classList.contains('active') 
    ? '<i class="fas fa-times"></i>' 
    : '<i class="fas fa-bars"></i>';
});
// Recherche de véhicules
const searchBar = document.getElementById('search-bar');
const resultsDiv = document.getElementById('results');
const cars = [
  'Mercedes GLE', 
  'Audi A7', 
  'BMW X6', 
  'Porsche Panamera', 
  'Lamborghini Urus'
];

searchBar.addEventListener('input', () => {
  const searchTerm = searchBar.value.toLowerCase();
  resultsDiv.innerHTML = '';

  if (searchTerm.length > 0) {
    const filteredCars = cars.filter(car => 
      car.toLowerCase().includes(searchTerm)
    );

    if (filteredCars.length > 0) {
      filteredCars.forEach(car => {
        const p = document.createElement('p');
        p.textContent = car;
        resultsDiv.appendChild(p);
      });
    } else {
      resultsDiv.innerHTML = '<p>Aucun véhicule trouvé</p>';
    }
  }
});